/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/***** MACROS ******/
/* Explain: https://www.tutorialandexample.com/define-in-c/ */
#define DISPLAY(x) UART_write(uart, &output, x);


/***** GLOBAL VARIABLES *****/
// Driver Handles - Global variables
UART_Handle uart;
I2C_Handle i2c;
Timer_Handle timer0;

// UART Global Variables
char output[64];
int bytesToSend;

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// state machine
enum Change_Temperature {Increase_Setpoint, Decrease_Setpoint, None_Setpoint} Change_Temperature;
enum Heating_Status {Heating_On, Heating_Off, AC_On, AC_Off} Heating_Status;
enum Tick_Function {SetpointTemperature_Task, RoomTemperature_Task, ThermostatReadings_Task, Defaulted_Task} Tick_Function;

/***** DEFINE STRUCTURES *****/
// task
typedef struct Task {
    int state;
    unsigned long period;
    unsigned char timerFlag;
    unsigned long elapsedTime;
    unsigned long periodGCD;
    void (*TickFct)();
} Task;

// three tasks needed within the task scheduler
const unsigned taskNum = 3;
Task task[taskNum];
signed char setpointTemp = 22; // 22 degrees C = approx 72 F
signed char setpointTemperature;
signed char roomTemperature;

const unsigned periodSetpoinnt = 200; //ms
const unsigned periodRoomTemp = 500;
const unsigned periodReadinfs = 1000;
const unsigned taskPeriodGCD = 100;


/***** INITIALIZE FUNCTIONS *****/
// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"))

    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses

    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;

        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"))
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"))
        }

    if(found)
    {
    DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address:%x\n\r", sensors[i].id, i2cTransaction.slaveAddress))
    }
    else
    {
    DISPLAY(snprintf(output, 64, "Temperature sensor not found,contact professor\n\r"))
    }
}

void initUART(void)
{
    UART_Params uartParams;
    // Init the driver
    UART_init();
    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;
    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

volatile unsigned char TimerFlag = 0;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}

void initTimer(void)
{
    Timer_Params params;
    // Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
    params.period = 100000; // 100 milliseconds
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.periodUnits = Timer_PERIOD_US;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}


/****** *****/
/* Task Scheduler for time (Round robin)
 * for each tasks, call its "tick" function if task's period is up
 */
// TimerISR??
void Ticks() {
    unsigned int i;
   for (i=0; i < taskNum; i++) {
        if (task[i].elapsedTime >= task[i].period) {
            // task is ready to "tick" aka execution, calling its functioning

            //FIXME: INCOMPATIBLE WITH FUNCTION
            //task[i].state = task[i].TickFct(task[i].state);
            //thermostatTick(task[i].state);
            task[i].elapsedTime = 0;
            printf("Tickloop" + 1);
        }
        task[i].elapsedTime += taskPeriodGCD;
    }

}

// I2C peripheral
int16_t readTemp(void)
{
    int j;
    int16_t temperature = 0;

    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        *Extract degrees C from the received data;
        *see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        /*
        *If the MSB is set '1', then we have a 2's complement
        * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperaturesensor (%d)\n\r",i2cTransaction.status))
        DISPLAY(snprintf(output, 64, "Please power cycle your boardby unplugging USB and plugging back in.\n\r"))
    }

    return temperature;
}


/***** BUTTONS *****/
/*  gpioButtonFxn0 */
// sends request to decrease setpoint temperature
void gpioButtonFxn0(uint_least8_t index)
{
    Change_Temperature = Decrease_Setpoint;
}

/* gpioButtonFxn1 */
// sends request to increase setpoint temperature
void gpioButtonFxn1(uint_least8_t index)
{
    Change_Temperature = Increase_Setpoint;
}


/***** PRIMARY TASKS *****/
// check if user increase/decreases the "setpoint"/desired temperature
int SetpointTemperature(signed char setpointTemp) {
    printf("TASK SET: ");

    if (Change_Temperature == Increase_Setpoint) {
        setpointTemp += 1;
        printf("%02d", setpointTemp);
        printf("set up\n");
    }
    if (Change_Temperature == Decrease_Setpoint) {
        setpointTemp -= 1;
        printf("%02d", setpointTemp);
        printf("set down\n");
    }

    Change_Temperature = None_Setpoint;

    return setpointTemp;
}

// adjusts heating/status based on current room temperature

int AutoTemperatureAdjustment(signed char setpointTemp) {
   // read roomTemp (Celsius)
    readTemp();
    signed char roomTemp = readTemp();

    // heating is turned on
    if (roomTemp < setpointTemp) {
        Heating_Status = Heating_On;
        // indicate status by turning ON LED light
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        printf("heat on\n");
    }
    // heating is turned off
    else {
        Heating_Status = Heating_Off;
        // indicate status by turning OFF LED light
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        printf("heat off\n");
    }

    return roomTemp;
}

// combine readings into thermostat output:
// the readings are: room temperature (AA), setpoint temperature (BB), heating status (S), and time since reset (CCCC)
void ThermostatReadings(signed char setpointTemp, signed char roomTemp) {
    // heating status
    printf("TASK DISPLAY: ");
    unsigned char heating;
    unsigned long timerCount = Timer_getCount(timer0);

    if (Heating_Status == Heating_On) {
        heating = 1;
        printf("S is on \n");
    }
    if (Heating_Status == Heating_Off) {
        heating = 0;
        printf("S is off \n");
    }

    printf("%04d\n", timerCount);

    DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", roomTemp, setpointTemp, heating, timerCount))
}

void ThermostatFunctions(Tick_Function) {
    switch (Tick_Function) {
        case SetpointTemperature_Task:
            // every 200ms check the button flags
            // check if user increase/decreases the "setpoint"/desired temperature
            setpointTemperature = SetpointTemperature(setpointTemp);
            printf("new stpt reading: ");
            printf("%02d\n", setpointTemperature);
            break;
        case RoomTemperature_Task:
            //every 500s, read the temperature and update the LED
            roomTemperature = AutoTemperatureAdjustment(setpointTemperature);
            printf("new room reading: ");
            printf("%02d\n", roomTemperature);
            break;
        case ThermostatReadings_Task:
            //every second output the following to the UART: "<%02d,%02d,%d,$04d>\n\r", temperature, setpoint, hear, seconds
            ThermostatReadings(setpointTemperature, roomTemperature);
            break;
        default:
            break;
    }
    return;
}

/********** MAIN THREAD **********/
void *mainThread(void *arg0)
{
    GPIO_init();
    initUART();
    initI2C();
    initTimer();

    Timer_start(timer0);

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    // Turn on user LED
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    // enables input button 0
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    // enables input button 1
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /* remember the ranges:
         signed char is -128 to 127, minimum siz
         unsigned char is int 0 to 255
    */

    // declarations
    unsigned char i = 0;
    task[i].state = SetpointTemperature_Task;
    task[i].timerFlag = 0;
    task[i].period = 200000; // 200 milliseconds;
    task[i].elapsedTime = task[i].period;
    task[i].TickFct = &ThermostatFunctions;
    ++i;
    task[i].state = RoomTemperature_Task;
    task[i].timerFlag = 0;
    task[i].period = 500000; // 500 milliseconds;
    task[i].elapsedTime = task[i].period;
    task[i].TickFct = &ThermostatFunctions;
    ++i;
    task[i].state = ThermostatReadings_Task;
    task[i].timerFlag = 0;
    task[i].period = 1000000; // 1 second or 1000 milliseconds;
    task[i].elapsedTime = task[i].period;
    task[i].TickFct = &ThermostatFunctions;

    Ticks();

    /*
       while(!timerFlag[i])() //wait for timer period
            TimerFlag = 0;  // lower flat rained by timer
        ++timer;
    */

    //TODO: add flats to button handlers (similar to timer flag)
   // while(1) {
    /*
        // every 200ms check the button flags
        // check if user increase/decreases the "setpoint"/desired temperature
        setpointTemperature = SetpointTemperature(setpointTemp);
        printf("new stpt reading: ");
        printf("%02d\n", setpointTemperature);

        sleep(1);
        //TODO: every 500s, read the temperature and update the LED
        roomTemperature = AutoTemperatureAdjustment(setpointTemperature);
        printf("new room reading: ");
        printf("%02d\n", roomTemperature);

        //TODO: every second output the following to the UART: "<%02d,%02d,%d,$04d>\n\r", temperature, setpoint, hear, seconds
        ThermostatReadings(setpointTemperature, roomTemperature);
        //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

        //DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,$04d>\n\r", temperature, setpoint, hear, seconds))
        // ASSISTANCE: Zybooks: converting different-period tasks to C
        // remeber to configure the timer period

        sleep(3);
*/
    printf("---END \n ");

    return (NULL);
}


